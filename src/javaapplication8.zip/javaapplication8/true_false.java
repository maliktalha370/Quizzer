/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;

import java.io.Serializable;

/**
 *
 * @author Talha Zubair
 */
public class true_false implements Serializable {
  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    public String quo;
    public String ans;
    true_false(String a,String b)
    {
        quo=a;
        ans=b;
    }
   
    
}


